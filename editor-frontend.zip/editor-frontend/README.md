# editor-frontend

Frontend container for editor service, runs on port 80.
